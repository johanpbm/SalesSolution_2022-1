#pragma once
using namespace System;
using namespace System::Collections::Generic;
using namespace SalesModel;

namespace SalesController {
	public ref class WarehouseDB
	{
	public:
		/*Complete los atributos y m�todos faltantes*/
	};
}
