#include "pch.h"
#include "StoreProductDB.h"
using namespace System::IO;
using namespace System::Globalization;
using namespace System::Runtime::Serialization;
using namespace System::Runtime::Serialization::Formatters::Binary;

void SalesController::StoreProductDB::Persist()
{
}

