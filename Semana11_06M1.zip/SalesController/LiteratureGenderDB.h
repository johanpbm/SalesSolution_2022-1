#pragma once
using namespace SalesModel;
using namespace System::Collections::Generic;

public ref class LiteratureGenderDB
{
public:
	List<LiteratureGender^>^ ListDB = gcnew List<LiteratureGender^>();
};

