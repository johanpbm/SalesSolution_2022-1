#include "ChatForm.h"
#include "SalesMainForm.h"

System::Void SalesView::ChatForm::BtnAdd_Click(System::Object^ sender, System::EventArgs^ e) {
}

System::Void SalesView::ChatForm::ChatForm_Load(System::Object^ sender, System::EventArgs^ e) {
}