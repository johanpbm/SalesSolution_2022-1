#pragma once
using namespace System;

namespace SalesModel {
	[Serializable]
	public ref class LiteratureGender
	{
	public:
		property int Id;
		property String^ Name;
	};

}
