#include "pch.h"
#include "Store.h"

/**
 * Store implementation
 */
