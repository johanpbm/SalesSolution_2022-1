#include "pch.h"
#include "Sale.h"

/**
 * Sale implementation
 */
