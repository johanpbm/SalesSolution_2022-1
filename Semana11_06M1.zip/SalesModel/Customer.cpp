/**
 * Project SalesSolution
 */
#include "pch.h"
#include "Customer.h"

/**
 * Customer implementation
 */
