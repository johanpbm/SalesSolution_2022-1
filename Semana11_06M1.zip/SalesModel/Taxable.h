/**
	 La interfaz Taxable modela un contrato de obligaci�n para quien implemente o realice la interfaz, debe de programar el m�todo GetTax().
 */
public interface class Taxable {
	double GetTax();
};