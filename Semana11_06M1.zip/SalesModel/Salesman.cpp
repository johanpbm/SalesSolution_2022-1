/**
 * Project SalesSolution
 */
#include "pch.h"
#include "Salesman.h"

/**
 * Salesman implementation
 */
