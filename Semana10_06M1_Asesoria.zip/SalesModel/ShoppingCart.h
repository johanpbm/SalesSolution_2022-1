using namespace System;

namespace SalesModel {
	[Serializable]
	public ref class ShoppingCart
	{
	};
}
