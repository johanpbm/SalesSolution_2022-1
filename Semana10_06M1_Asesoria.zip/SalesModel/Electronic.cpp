#include "pch.h"
#include "Electronic.h"

/**
 * Electronic implementation
 */

double SalesModel::Electronic::GetTax() {
    return 0.0;
}
