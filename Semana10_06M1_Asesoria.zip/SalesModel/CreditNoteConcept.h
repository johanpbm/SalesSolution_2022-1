/**
 * Project SalesSolution
 */
#pragma once
using namespace System;

namespace SalesModel {
    [Serializable]
    public ref class CreditNoteConcept {
        public:
            int Id;
            String^ Description;
    };
}