/**
 * Project SalesSolution
 */
#include "pch.h"
#include "Manager.h"

/**
 * Manager implementation
 */
