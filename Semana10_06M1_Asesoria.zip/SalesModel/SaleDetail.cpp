#include "pch.h"
#include "SaleDetail.h"

/**
 * SaleDetail implementation
 */
