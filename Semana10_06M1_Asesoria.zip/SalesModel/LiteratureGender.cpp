#include "pch.h"
#include "LiteratureGender.h"
