#include "pch.h"
#include "Company.h"

/**
 * Company implementation
 */
