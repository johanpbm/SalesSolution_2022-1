#include "pch.h"
#include "LiteratureGenderDB.h"
